﻿#requires -Version 5.1
<#
    智慧树学习助手
    - 通过 Windows UI Automation 控制已登录的 Edge 页面
    - 自动播放当前视频、检测随堂练习、跳过章节测试后继续下一节
    - 配置了 OpenAI 兼容接口的 API Key 时可自动作答；没有 Key 时手动选择
    - 不进入、不提交章节测试，不绕过人脸识别、监考或平台限制
#>

param(
    [switch]$Probe,
    [switch]$DryRun,
    [switch]$Once
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms

if (-not ('ZHelperNative' -as [type])) {
    Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Threading;

public static class ZHelperNative
{
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }

    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern void SwitchToThisWindow(IntPtr hWnd, bool fAltTab);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT lpPoint);
    [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();

    public static void Click(int x, int y)
    {
        POINT old;
        GetCursorPos(out old);
        SetCursorPos(x, y);
        Thread.Sleep(90);
        mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
        Thread.Sleep(55);
        mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
        Thread.Sleep(90);
        SetCursorPos(old.X, old.Y);
    }
}
'@
}

$script:Root = Join-Path $PSScriptRoot 'logs'
if (-not (Test-Path -LiteralPath $script:Root)) {
    New-Item -ItemType Directory -Path $script:Root -Force | Out-Null
}
$script:LogPath = Join-Path $script:Root ('run-{0:yyyyMMdd}.log' -f (Get-Date))
$script:LastLogState = ''

function Write-Log {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Info', 'Ok', 'Warn', 'Error', 'Quiz')][string]$Level = 'Info'
    )
    $line = '[{0:HH:mm:ss}] {1}' -f (Get-Date), $Message
    $color = switch ($Level) {
        'Ok'    { 'Green' }
        'Warn'  { 'Yellow' }
        'Error' { 'Red' }
        'Quiz'  { 'Cyan' }
        default { 'Gray' }
    }
    Write-Host $line -ForegroundColor $color
    try { Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8 } catch { }
}

function Get-Config {
    $defaults = [ordered]@{
        autoAnswer        = $true
        autoNext          = $true
        skipChapterTests  = $true
        pollSeconds       = 2
        apiBase           = 'https://api.deepseek.com'
        model             = 'deepseek-chat'
        apiKey            = ''
    }

    $path = Join-Path $PSScriptRoot 'config.json'
    if (Test-Path -LiteralPath $path) {
        try {
            $loaded = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($p in $loaded.PSObject.Properties) {
                if ($defaults.Contains($p.Name)) { $defaults[$p.Name] = $p.Value }
            }
        }
        catch {
            Write-Log "config.json 读取失败，使用默认配置：$($_.Exception.Message)" Warn
        }
    }

    if ($env:DEEPSEEK_API_KEY) { $defaults['apiKey'] = $env:DEEPSEEK_API_KEY }
    if ($env:ZHIHUISHU_API_KEY) { $defaults['apiKey'] = $env:ZHIHUISHU_API_KEY }
    if ([int]$defaults['pollSeconds'] -lt 1) { $defaults['pollSeconds'] = 1 }

    return [pscustomobject]$defaults
}

function Get-EdgeContext {
    # Edge 最小化时，Chromium 不会把标签栏和后台标签暴露给 UI Automation，先恢复窗口
    $edgeWindows = @(Get-Process msedge -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 })
    $restored = $false
    foreach ($ep in $edgeWindows) {
        if ([ZHelperNative]::IsIconic($ep.MainWindowHandle)) {
            [ZHelperNative]::ShowWindow($ep.MainWindowHandle, 9) | Out-Null
            $restored = $true
        }
    }
    if ($restored) { Start-Sleep -Milliseconds 700 }

    $rootElement = [System.Windows.Automation.AutomationElement]::RootElement
    $windows = $rootElement.FindAll(
        [System.Windows.Automation.TreeScope]::Children,
        [System.Windows.Automation.Condition]::TrueCondition
    )
    $docCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Document
    )
    $tabCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::TabItem
    )

    for ($i = 0; $i -lt $windows.Count; $i++) {
        $w = $windows.Item($i)
        try {
            if ($w.Current.ClassName -ne 'Chrome_WidgetWin_1') { continue }
            $proc = Get-Process -Id $w.Current.ProcessId -ErrorAction SilentlyContinue
            if (-not $proc -or $proc.ProcessName -ne 'msedge') { continue }

            # 当前激活页就是智慧树
            $doc = $w.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $docCondition)
            if ($doc -and $doc.Current.Name -eq '智慧树') {
                return [pscustomobject]@{
                    Window   = $w
                    Document = $doc
                    Hwnd     = [IntPtr]$w.Current.NativeWindowHandle
                }
            }

            # 当前激活的是别的标签页：在同一个 Edge 窗口里找回智慧树标签
            $tabs = $w.FindAll([System.Windows.Automation.TreeScope]::Descendants, $tabCondition)
            for ($j = 0; $j -lt $tabs.Count; $j++) {
                $tab = $tabs.Item($j)
                try {
                    if ($tab.Current.Name -notmatch '智慧树') { continue }
                    try {
                        $select = $tab.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
                        $select.Select()
                    }
                    catch {
                        $tab.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
                    }
                    Start-Sleep -Milliseconds 800
                    $doc = $w.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $docCondition)
                    if ($doc -and $doc.Current.Name -eq '智慧树') {
                        return [pscustomobject]@{
                            Window   = $w
                            Document = $doc
                            Hwnd     = [IntPtr]$w.Current.NativeWindowHandle
                        }
                    }
                }
                catch { }
            }
        }
        catch { }
    }
    return $null
}

function Get-EdgeHwnd {
    $windows = Get-Process msedge -ErrorAction SilentlyContinue |
        Where-Object { $_.MainWindowHandle -ne 0 }
    $p = $windows | Where-Object { $_.MainWindowTitle -match '智慧树' } | Select-Object -First 1
    if (-not $p) { $p = $windows | Select-Object -First 1 }
    if ($p) { return [IntPtr]$p.MainWindowHandle }
    return [IntPtr]::Zero
}

function Focus-Edge {
    param($Context)
    $hwnd = [IntPtr]::Zero
    if ($Context) {
        try { $hwnd = [IntPtr]$Context.Hwnd } catch { }
    }
    if ($hwnd -eq [IntPtr]::Zero) { $hwnd = Get-EdgeHwnd }
    if ($hwnd -ne [IntPtr]::Zero) {
        if ([ZHelperNative]::IsIconic($hwnd)) {
            [ZHelperNative]::ShowWindow($hwnd, 9) | Out-Null
            Start-Sleep -Milliseconds 350
            [ZHelperNative]::SwitchToThisWindow($hwnd, $false)
        }
        [ZHelperNative]::SetForegroundWindow($hwnd) | Out-Null
        Start-Sleep -Milliseconds 180
    }
}

function Focus-Console {
    $hwnd = [ZHelperNative]::GetConsoleWindow()
    if ($hwnd -ne [IntPtr]::Zero) {
        [ZHelperNative]::ShowWindowAsync($hwnd, 9) | Out-Null
        [ZHelperNative]::SetForegroundWindow($hwnd) | Out-Null
        Start-Sleep -Milliseconds 120
    }
}

function Get-AllByClass {
    param(
        [Parameter(Mandatory)]$RootElement,
        [Parameter(Mandatory)][string]$Pattern
    )
    $all = $RootElement.FindAll(
        [System.Windows.Automation.TreeScope]::Descendants,
        [System.Windows.Automation.Condition]::TrueCondition
    )
    $list = New-Object System.Collections.Generic.List[object]
    for ($i = 0; $i -lt $all.Count; $i++) {
        $e = $all.Item($i)
        try {
            if ($e.Current.ClassName -match $Pattern) { $list.Add($e) }
        }
        catch { }
    }
    return @($list.ToArray())
}

function Get-SectionLabel {
    param([Parameter(Mandatory)]$Element)
    $textCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Text
    )
    $texts = $Element.FindAll([System.Windows.Automation.TreeScope]::Descendants, $textCondition)
    for ($i = 0; $i -lt $texts.Count; $i++) {
        $n = $texts.Item($i).Current.Name.Trim()
        if ($n -match '^\d+(\.\d+)+$') { return $n }
    }
    return $null
}

function Expand-AllChapters {
    param([Parameter(Mandatory)]$Document)
    $buttonCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Button
    )
    $buttons = $Document.FindAll([System.Windows.Automation.TreeScope]::Descendants, $buttonCondition)
    $changed = 0
    for ($i = 0; $i -lt $buttons.Count; $i++) {
        $b = $buttons.Item($i)
        try {
            if ($b.Current.Name -notmatch '^第.+章') { continue }
            $pattern = $b.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern)
            if ($pattern.Current.ExpandCollapseState -eq [System.Windows.Automation.ExpandCollapseState]::Collapsed) {
                $pattern.Expand()
                $changed++
                Start-Sleep -Milliseconds 180
            }
        }
        catch { }
    }
    if ($changed -gt 0) { Start-Sleep -Milliseconds 700 }
    return $changed
}

function Get-SectionItems {
    param([Parameter(Mandatory)]$Document)
    $all = $Document.FindAll(
        [System.Windows.Automation.TreeScope]::Descendants,
        [System.Windows.Automation.Condition]::TrueCondition
    )
    $items = New-Object System.Collections.Generic.List[object]
    $seen = New-Object System.Collections.Generic.HashSet[string]

    for ($i = 0; $i -lt $all.Count; $i++) {
        $e = $all.Item($i)
        try {
            $cls = $e.Current.ClassName
            $kind = $null
            if ($cls -match '^chapter-item(\s|$)') { $kind = 'section' }
            elseif ($cls -match '^chapter-content-second(\s|$)') { $kind = 'subsection' }
            elseif ($cls -eq 'test-box') { $kind = 'test' }

            if (-not $kind) { continue }

            if ($kind -eq 'test') {
                $label = '测试'
            }
            else {
                $label = Get-SectionLabel -Element $e
                if (-not $label) { continue }
            }

            if ($kind -eq 'test') {
                # 每个章节末尾都有“测试”，不能按标签去重
                $key = "test|$i"
            }
            else {
                $key = "$kind|$label"
            }
            if (-not $seen.Add($key)) { continue }

            $items.Add([pscustomobject]@{
                Label   = $label
                Kind    = $kind
                Element = $e
            })
        }
        catch { }
    }
    return @($items.ToArray())
}

function Find-CurrentSection {
    param([Parameter(Mandatory)]$Document)
    $items = Get-SectionItems -Document $Document
    foreach ($item in $items) {
        try {
            if ($item.Element.Current.ClassName -match '(^|\s)current(\s|$)') {
                return $item.Label
            }
        }
        catch { }
    }
    return $null
}

function Get-VideoState {
    param([Parameter(Mandatory)]$Document)
    $nameCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::NameProperty,
        'video player'
    )
    $video = $Document.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $nameCondition)
    if (-not $video) {
        $candidates = Get-AllByClass -RootElement $Document -Pattern 'vjs_container'
        if ($candidates.Count -gt 0) { $video = $candidates[0] }
    }
    if (-not $video) {
        return [pscustomobject]@{ State = 'missing'; Element = $null; ClassName = '' }
    }

    $cls = ''
    try { $cls = $video.Current.ClassName } catch { }
    $state = 'paused'
    if ($cls -match 'vjs-ended') { $state = 'ended' }
    elseif ($cls -match 'vjs-playing') { $state = 'playing' }

    return [pscustomobject]@{
        State     = $state
        Element   = $video
        ClassName = $cls
    }
}

function Get-Quiz {
    param([Parameter(Mandatory)]$Document)
    $exact = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ClassNameProperty,
        'el-dialog is-draggable is-align-center ai-class-exercise-dialog'
    )
    $quiz = $Document.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $exact)
    if ($quiz) { return $quiz }

    $fallback = Get-AllByClass -RootElement $Document -Pattern 'ai-class-exercise-dialog'
    if ($fallback.Count -gt 0) { return $fallback[0] }
    return $null
}

function Get-QuizData {
    param([Parameter(Mandatory)]$QuizElement)

    $textCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Text
    )
    $texts = $QuizElement.FindAll([System.Windows.Automation.TreeScope]::Descendants, $textCondition)
    $names = @()
    for ($i = 0; $i -lt $texts.Count; $i++) {
        $n = $texts.Item($i).Current.Name.Trim()
        if ($n) { $names += $n }
    }

    $typeIndex = -1
    $type = '题目'
    for ($i = 0; $i -lt $names.Count; $i++) {
        if ($names[$i] -match '^\d+\.\s*\[(.+?)\]') {
            $type = $matches[1].Trim()
            $typeIndex = $i
            break
        }
    }

    $stemParts = @()
    if ($typeIndex -ge 0) {
        for ($i = $typeIndex + 1; $i -lt $names.Count; $i++) {
            $n = $names[$i]
            if ($n -match '^[A-H]$') { break }
            if ($n -match '^\[.+\]$') { break }
            if ($n -eq '提交作答' -or $n -eq 'AI随堂练习') { break }
            $stemParts += $n
            if ($stemParts.Count -ge 12) { break }
        }
    }
    $stem = ($stemParts -join ' ').Trim()
    if (-not $stem) {
        $stem = $QuizElement.Current.Name -replace '^.*?\[[^\]]+\]\s*', ''
        $stem = $stem -replace '\s+[A-H]\s+.*$', ''
        $stem = $stem.Trim()
    }

    $optionGroups = Get-AllByClass -RootElement $QuizElement -Pattern '^option$'
    $options = @()
    $index = 0
    foreach ($g in $optionGroups) {
        $t = $g.FindAll([System.Windows.Automation.TreeScope]::Descendants, $textCondition)
        $parts = @()
        for ($i = 0; $i -lt $t.Count; $i++) {
            $n = $t.Item($i).Current.Name.Trim()
            if ($n) { $parts += $n }
        }
        $raw = ($parts -join ' ').Trim()
        if (-not $raw) { continue }

        $label = [char]([int][char]'A' + $index)
        $optionText = $raw
        if ($raw -match '^([A-H])[\s\.、:：]*(.*)$') {
            $label = $matches[1]
            $optionText = $matches[2].Trim()
        }
        if (-not $optionText) { $optionText = $raw }
        $options += [pscustomobject]@{
            Label   = $label
            Text    = $optionText
            Raw     = $raw
            Element = $g
        }
        $index++
    }

    $buttonCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Button
    )
    $buttons = $QuizElement.FindAll([System.Windows.Automation.TreeScope]::Descendants, $buttonCondition)
    $submit = $null
    for ($i = 0; $i -lt $buttons.Count; $i++) {
        $n = $buttons.Item($i).Current.Name.Trim()
        if ($n -match '提交作答|提交|确定' -and $n -notmatch '取消') {
            $submit = $buttons.Item($i)
            break
        }
    }

    return [pscustomobject]@{
        Type    = $type
        Stem    = $stem
        Options = @($options)
        Submit  = $submit
        RawName = $QuizElement.Current.Name
    }
}

function Get-QuizKey {
    param([Parameter(Mandatory)]$Quiz)
    $opt = ($Quiz.Options | ForEach-Object { "$($_.Label)=$($_.Text)" }) -join '|'
    return "$($Quiz.Type)|$($Quiz.Stem)|$opt"
}

function Show-Quiz {
    param([Parameter(Mandatory)]$Quiz)
    Write-Host ''
    Write-Host ('=' * 68) -ForegroundColor DarkCyan
    Write-Host "  随堂练习（$($Quiz.Type)）" -ForegroundColor Cyan
    Write-Host ('=' * 68) -ForegroundColor DarkCyan
    Write-Host $Quiz.Stem -ForegroundColor White
    Write-Host ''
    foreach ($o in $Quiz.Options) {
        Write-Host ("  {0}. {1}" -f $o.Label, $o.Text) -ForegroundColor Gray
    }
    Write-Host ''
}

function Read-ManualAnswer {
    param([Parameter(Mandatory)]$Quiz)
    if ($Quiz.Options.Count -eq 0) {
        Write-Log '这个题型没有可点击选项，请在网页中手动完成。' Warn
        return @()
    }

    Focus-Console
    $valid = @($Quiz.Options | ForEach-Object { $_.Label })
    while ($true) {
        $raw = Read-Host ("请输入答案字母（如 A；多选如 A,C；输入 Q 退出）")
        if ($null -eq $raw) { return @() }
        $raw = $raw.Trim().ToUpperInvariant()
        if ($raw -eq 'Q') {
            $script:StopRequested = $true
            return @()
        }
        if ($Quiz.Type -match '判断') {
            if ($raw -eq '对' -or $raw -eq '正确' -or $raw -eq '√') { $raw = 'A' }
            elseif ($raw -eq '错' -or $raw -eq '错误' -or $raw -eq '×') { $raw = 'B' }
        }
        $letters = @([regex]::Matches($raw, '[A-H]') | ForEach-Object { $_.Value } | Select-Object -Unique)
        $bad = @($letters | Where-Object { $valid -notcontains $_ })
        if ($letters.Count -gt 0 -and $bad.Count -eq 0) {
            if ($Quiz.Type -match '判断|单选' -and $letters.Count -gt 1) {
                Write-Host "本题只能选一个选项。" -ForegroundColor Yellow
                continue
            }
            return $letters
        }
        Write-Host ("无效答案，可选：{0}" -f ($valid -join ', ')) -ForegroundColor Yellow
    }
}

function Invoke-Option {
    param([Parameter(Mandatory)]$Option)
    try {
        $p = $Option.Element.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        $p.Invoke()
        return $true
    }
    catch {
        try {
            $p = $Option.Element.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
            $p.Select()
            return $true
        }
        catch { return $false }
    }
}

function Submit-QuizAnswer {
    param(
        [Parameter(Mandatory)]$Quiz,
        [Parameter(Mandatory)][string[]]$Letters
    )
    $chosen = @()
    foreach ($o in $Quiz.Options) {
        if ($Letters -contains $o.Label) {
            if (Invoke-Option -Option $o) {
                $chosen += $o.Label
                Start-Sleep -Milliseconds 160
            }
        }
    }
    if ($chosen.Count -eq 0) {
        Write-Log '没有成功选中任何选项，未提交。' Warn
        return $false
    }
    if (-not $Quiz.Submit) {
        Write-Log '没有找到“提交作答”按钮，请在网页中手动提交。' Warn
        return $false
    }

    Start-Sleep -Milliseconds 350
    try {
        $p = $Quiz.Submit.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        $p.Invoke()
    }
    catch {
        Write-Log "提交按钮点击失败：$($_.Exception.Message)" Error
        return $false
    }

    Write-Log ("已提交：{0}" -f ($chosen -join ',')) Ok
    return $true
}

function Dismiss-Quiz {
    param([Parameter(Mandatory)]$QuizElement)
    $buttonCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Button
    )
    $buttons = $QuizElement.FindAll([System.Windows.Automation.TreeScope]::Descendants, $buttonCondition)
    $names = @('继续学习', '知道了', '关闭', '确定', '完成')
    foreach ($want in $names) {
        for ($i = 0; $i -lt $buttons.Count; $i++) {
            $b = $buttons.Item($i)
            if ($b.Current.Name.Trim() -eq $want) {
                try {
                    $b.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
                    Start-Sleep -Milliseconds 600
                    return $true
                }
                catch { }
            }
        }
    }
    return $false
}

function Ask-DeepSeek {
    param(
        [Parameter(Mandatory)]$Quiz,
        [Parameter(Mandatory)]$Config
    )
    $key = [string]$Config.apiKey
    if (-not $key) { return $null }

    $optionLines = ($Quiz.Options | ForEach-Object { "$($_.Label). $($_.Text)" }) -join "`n"
    $system = '你是一个严谨的课程随堂练习答题助手。只输出 JSON，不要输出 Markdown 代码块。'
    $user = @"
课程：人工智能导论
题型：$($Quiz.Type)
题目：$($Quiz.Stem)
选项：
$optionLines

要求：
1. 判断题、单选题只选一个；多选题可以选多个。
2. answer 必须是选项字母数组，例如 ["A"]。
3. confidence 为 0 到 1 之间的小数，reason 用不超过 60 个汉字说明理由。
4. 只返回 JSON：{"answer":["A"],"confidence":0.9,"reason":"简短理由"}
"@

    $body = [ordered]@{
        model       = [string]$Config.model
        messages    = @(
            @{ role = 'system'; content = $system },
            @{ role = 'user'; content = $user }
        )
        temperature = 0
        max_tokens  = 300
        response_format = @{ type = 'json_object' }
    }

    $base = ([string]$Config.apiBase).TrimEnd('/')
    $uri = "$base/chat/completions"
    $headers = @{ Authorization = "Bearer $key" }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $response = $null
    $json = $body | ConvertTo-Json -Depth 6 -Compress
    $payload = [Text.Encoding]::UTF8.GetBytes($json)
    try {
        $response = Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -ContentType 'application/json; charset=utf-8' -Body $payload -TimeoutSec 45
    }
    catch {
        Write-Log "AI 请求失败，尝试兼容模式：$($_.Exception.Message)" Warn
        $body.Remove('response_format')
        $json = $body | ConvertTo-Json -Depth 6 -Compress
        $payload = [Text.Encoding]::UTF8.GetBytes($json)
        try {
            $response = Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -ContentType 'application/json; charset=utf-8' -Body $payload -TimeoutSec 45
        }
        catch {
            Write-Log "AI 请求仍然失败：$($_.Exception.Message)" Error
            return $null
        }
    }

    try {
        $content = [string]$response.choices[0].message.content
        $content = $content.Trim()
        $content = $content -replace '^```(?:json)?\s*', '' -replace '\s*```$', ''
        $obj = $content | ConvertFrom-Json

        $letters = @()
        foreach ($a in @($obj.answer)) {
            foreach ($m in [regex]::Matches([string]$a, '[A-H]')) { $letters += $m.Value }
        }
        $valid = @($Quiz.Options | ForEach-Object { $_.Label })
        $letters = @($letters | Where-Object { $valid -contains $_ } | Select-Object -Unique)
        if ($letters.Count -eq 0) { return $null }
        if ($Quiz.Type -match '判断|单选') { $letters = @($letters[0]) }

        return [pscustomobject]@{
            Letters    = $letters
            Confidence = $obj.confidence
            Reason     = [string]$obj.reason
        }
    }
    catch {
        Write-Log "AI 返回内容无法解析：$($_.Exception.Message)" Warn
        return $null
    }
}

function Invoke-PlayVideo {
    param([Parameter(Mandatory)]$Context)
    $state = Get-VideoState -Document $Context.Document
    if ($state.State -ne 'paused') { return }

    $rect = $state.Element.Current.BoundingRectangle
    if ($rect.Width -lt 80 -or $rect.Height -lt 50) {
        Write-Log '视频区域太小，无法点击播放。' Warn
        return
    }

    $x = [int]($rect.X + $rect.Width / 2)
    $y = [int]($rect.Y + $rect.Height / 2)

    Focus-Edge -Context $Context
    [ZHelperNative]::Click($x, $y)
    Start-Sleep -Milliseconds 900

    $after = Get-VideoState -Document $Context.Document
    if ($after.State -eq 'paused') {
        [ZHelperNative]::Click($x, $y)
        Start-Sleep -Milliseconds 1400
        $after = Get-VideoState -Document $Context.Document
    }

    if ($after.State -eq 'playing') {
        Write-Log '视频已开始播放。' Ok
    }
    else {
        Write-Log "点击后视频仍未播放（状态：$($after.State)）。" Warn
    }
}

function Get-VideoRuntimeId {
    param($Video)
    if (-not $Video -or -not $Video.Element) { return '' }
    try { return ($Video.Element.GetRuntimeId() -join ',') } catch { return '' }
}

function Wait-VideoChanged {
    param(
        [string]$OldVideoId,
        [string]$OldState,
        [string]$OldLabel,
        [int]$TimeoutSeconds = 9
    )
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 650
        try {
            $ctx = Get-EdgeContext
            if (-not $ctx) { continue }
            $v = Get-VideoState -Document $ctx.Document
            if (-not $v.Element) { continue }
            $id = Get-VideoRuntimeId -Video $v
            $label = $null
            try { $label = Find-CurrentSection -Document $ctx.Document } catch { }
            $labelChanged = ($label -and $OldLabel -and $label -ne $OldLabel)

            # 新视频播放/暂停，并且视频元素或左侧当前小节确实变了，才算切换成功
            if (($v.State -eq 'playing' -or $v.State -eq 'paused') -and ($id -ne $OldVideoId -or $labelChanged)) {
                return [pscustomobject]@{ Changed = $true; State = $v.State; VideoId = $id; Label = $label; Context = $ctx }
            }
            if ($v.State -eq 'ended' -and $id -and $id -ne $OldVideoId) {
                return [pscustomobject]@{ Changed = $true; State = $v.State; VideoId = $id; Label = $label; Context = $ctx }
            }
        }
        catch { }
    }
    return [pscustomobject]@{ Changed = $false; State = 'unknown'; VideoId = ''; Label = $null; Context = $null }
}

function Move-NextSection {
    param(
        [Parameter(Mandatory)]$Context,
        [Parameter(Mandatory)]$Config
    )

    $ctxNow = Get-EdgeContext
    if ($ctxNow) { $Context = $ctxNow }

    # 章节可能是折叠的，先展开再取目录，避免目录不完整
    $expanded = Expand-AllChapters -Document $Context.Document
    if ($expanded -gt 0) { Write-Log "已展开 $expanded 个章节。" }

    $items = Get-SectionItems -Document $Context.Document
    if ($items.Count -eq 0) {
        Write-Log '没有读取到课程目录。' Warn
        return [pscustomobject]@{ Ok = $false; Fatal = $true; Label = ''; Skipped = @() }
    }

    $current = $script:CurrentLabel
    if (-not $current) { $current = Find-CurrentSection -Document $Context.Document }
    if (-not $current) {
        Write-Log '无法确定当前章节，请先在左侧目录点一下当前小节。' Warn
        return [pscustomobject]@{ Ok = $false; Fatal = $true; Label = ''; Skipped = @() }
    }

    $index = -1
    for ($i = 0; $i -lt $items.Count; $i++) {
        if ($items[$i].Label -eq $current) { $index = $i; break }
    }
    if ($index -lt 0) {
        Write-Log "目录中找不到当前小节：$current" Warn
        return [pscustomobject]@{ Ok = $false; Fatal = $true; Label = ''; Skipped = @() }
    }
    if ($index + 1 -ge $items.Count) {
        Write-Log '已经是目录最后一节。' Ok
        return [pscustomobject]@{ Ok = $false; Fatal = $true; Label = ''; Skipped = @() }
    }

    $oldVideo = Get-VideoState -Document $Context.Document
    $oldId = Get-VideoRuntimeId -Video $oldVideo
    $oldState = $oldVideo.State
    $skipped = New-Object System.Collections.Generic.List[string]
    $tried = 0
    $maxCandidates = 6

    # 从当前小节往后找，跳过测试；目录型小节没有视频时继续找它的子小节
    for ($i = $index + 1; $i -lt $items.Count -and $tried -lt $maxCandidates; $i++) {
        $cand = $items[$i]

        if ($cand.Kind -eq 'test') {
            if (-not $Config.skipChapterTests) {
                Write-Log '下一项是章节测试，且 skipChapterTests=false，程序停止。' Warn
                return [pscustomobject]@{ Ok = $false; Fatal = $true; Label = ''; Skipped = @($skipped) }
            }
            $skipped.Add($cand.Label)
            Write-Log '跳过章节测试（不进入、不提交）。' Warn
            continue
        }

        $tried++
        $ctx2 = Get-EdgeContext
        if (-not $ctx2) {
            Write-Log '页面暂时不可用，稍后重试。' Warn
            break
        }

        try {
            $scroll = $cand.Element.GetCurrentPattern([System.Windows.Automation.ScrollItemPattern]::Pattern)
            $scroll.ScrollIntoView()
            Start-Sleep -Milliseconds 350
            $invoke = $cand.Element.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
            $invoke.Invoke()
            Write-Log "尝试进入：$($cand.Label)"
        }
        catch {
            Write-Log "点击 $($cand.Label) 失败：$($_.Exception.Message)" Warn
            continue
        }

        $changed = Wait-VideoChanged -OldVideoId $oldId -OldState $oldState -OldLabel $current -TimeoutSeconds 9
        if ($changed.Changed) {
            $newLabel = $cand.Label
            if ($changed.Label -and $changed.Label -ne $current) { $newLabel = $changed.Label }
            $script:CurrentLabel = $newLabel
            $script:LastAdvanceAt = Get-Date
            Write-Log "已进入：$newLabel，视频状态：$($changed.State)" Ok
            return [pscustomobject]@{ Ok = $true; Fatal = $false; Label = $newLabel; Skipped = @($skipped) }
        }

        Write-Log "$($cand.Label) 没有加载出视频，继续尝试下一节。" Warn
    }

    $skipText = if ($skipped.Count -gt 0) { ($skipped -join '、') } else { '无' }
    Write-Log "本次没有找到可播放的下一节（已跳过测试：$skipText）。" Warn
    return [pscustomobject]@{ Ok = $false; Fatal = ($tried -eq 0); Label = ''; Skipped = @($skipped) }
}

function Show-Probe {
    param([Parameter(Mandatory)]$Config)
    $ctx = Get-EdgeContext
    if (-not $ctx) {
        Write-Log '没有找到标题含“智慧树”的 Edge 窗口。' Error
        return
    }
    Write-Log "Edge 窗口：$($ctx.Window.Current.Name)" Ok
    Write-Log "网页标题：$($ctx.Document.Current.Name)"

    $current = Find-CurrentSection -Document $ctx.Document
    Write-Log "当前小节：$(if($current){$current}else{'未识别'})"

    $video = Get-VideoState -Document $ctx.Document
    if ($video.Element) {
        Write-Log "视频状态：$($video.State)；区域：$($video.Element.Current.BoundingRectangle)"
    }
    else {
        Write-Log '视频状态：未找到视频元素' Warn
    }

    $quiz = Get-Quiz -Document $ctx.Document
    if ($quiz) {
        $q = Get-QuizData -QuizElement $quiz
        Write-Log "检测到随堂练习：$($q.Type)" Quiz
        Show-Quiz -Quiz $q
    }
    else {
        Write-Log '当前没有随堂练习弹窗。'
    }

    $items = Get-SectionItems -Document $ctx.Document
    Write-Log "目录小节数量：$($items.Count)"
    if ($items.Count -gt 0) {
        Write-Log ("前几节：{0}" -f (($items | Select-Object -First 8 | ForEach-Object { $_.Label }) -join ' -> '))
        Write-Log ("后几节：{0}" -f (($items | Select-Object -Last 5 | ForEach-Object { $_.Label }) -join ' -> '))
    }

    if ($Config.apiKey) { Write-Log "AI 自动答题：已配置 Key（长度 $(([string]$Config.apiKey).Length)）" Ok }
    else { Write-Log 'AI 自动答题：未配置 Key，将使用手动答题。' Warn }
}

function Main {
    $config = Get-Config
    $script:StopRequested = $false
    $script:CurrentLabel = $null
    $script:LastAdvanceAt = [datetime]::MinValue
    $script:LastQuizKey = $null
    $script:LastQuizAt = [datetime]::MinValue
    $script:LastEndedVideoId = $null
    $script:EndedAt = [datetime]::MinValue
    $script:AdvanceFailures = 0
    $script:NoVideoCount = 0
    $script:WaitingManualQuizKey = $null

    Write-Host ''
    Write-Host '  智慧树学习助手' -ForegroundColor Cyan
    Write-Host '  自动播放当前课程视频 / 随堂练习 / 跳过章节测试' -ForegroundColor DarkGray
    Write-Host '  视频按原速播放，Ctrl+C 可随时停止。' -ForegroundColor DarkGray
    Write-Host '  不进入、不提交章节测试，不绕过人脸识别或监考。' -ForegroundColor DarkGray
    Write-Host ''

    $ctx = Get-EdgeContext
    if (-not $ctx) {
        Write-Log '没有找到智慧树页面。请先在 Edge 中打开并登录课程页面。' Error
        return
    }

    Write-Log "已连接：$($ctx.Window.Current.Name)" Ok
    $expanded = Expand-AllChapters -Document $ctx.Document
    if ($expanded -gt 0) { Write-Log "已展开 $expanded 个章节。" }
    $script:CurrentLabel = Find-CurrentSection -Document $ctx.Document
    Write-Log "当前小节：$(if($script:CurrentLabel){$script:CurrentLabel}else{'未识别，请先在左侧点一下当前小节'})"

    if ($Probe) {
        Show-Probe -Config $config
        return
    }

    if (-not $config.apiKey) {
        Write-Log '未配置 API Key，遇到随堂练习时会暂停并让你输入答案。' Warn
        Write-Log '如需自动作答，在 config.json 填写 apiKey，或设置环境变量 DEEPSEEK_API_KEY。' Warn
    }

    $lastState = ''
    $emptyCycles = 0

    while (-not $script:StopRequested) {
        try {
            $ctx = Get-EdgeContext
            if (-not $ctx) {
                Write-Log '智慧树页面暂时不可用，等待 Edge 恢复...' Warn
                Start-Sleep -Seconds 3
                continue
            }

            $quiz = Get-Quiz -Document $ctx.Document
            if ($quiz) {
                $q = Get-QuizData -QuizElement $quiz
                $key = Get-QuizKey -Quiz $q

                if ($script:WaitingManualQuizKey -eq $key) {
                    Start-Sleep -Seconds 2
                    continue
                }

                if ($q.Options.Count -eq 0) {
                    Show-Quiz -Quiz $q
                    Write-Log '这个题型没有可自动点击的选项，请在网页中手动完成；完成后程序会自动继续。' Warn
                    $script:WaitingManualQuizKey = $key
                    Start-Sleep -Seconds 2
                    continue
                }

                if ($script:LastQuizKey -ne $key) {
                    Show-Quiz -Quiz $q
                    $letters = @()

                    if ($config.autoAnswer -and $config.apiKey) {
                        Write-Log '正在请求 AI 作答...' Quiz
                        $ai = Ask-DeepSeek -Quiz $q -Config $config
                        if ($ai) {
                            $letters = @($ai.Letters)
                            Write-Log ("AI 选择：{0}（置信度 {1}）{2}" -f ($letters -join ','), $ai.Confidence, $ai.Reason) Quiz
                        }
                        else {
                            Write-Log 'AI 没有给出有效答案，转为手动。' Warn
                        }
                    }

                    if ($letters.Count -eq 0) {
                        $letters = Read-ManualAnswer -Quiz $q
                    }

                    if ($script:StopRequested) { break }
                    if ($letters.Count -gt 0) {
                        if ($DryRun) {
                            Write-Log ("DryRun：本应提交 {0}，未点击。" -f ($letters -join ',')) Warn
                            $script:LastQuizKey = $key
                            $script:LastQuizAt = Get-Date
                        }
                        elseif (Submit-QuizAnswer -Quiz $q -Letters $letters) {
                            $script:LastQuizKey = $key
                            $script:LastQuizAt = Get-Date
                            Start-Sleep -Seconds 2
                            $still = Get-Quiz -Document $ctx.Document
                            if ($still) { Dismiss-Quiz -QuizElement $still | Out-Null }
                        }
                    }
                    else {
                        $script:WaitingManualQuizKey = $key
                    }
                }
                else {
                    # 已提交但弹窗仍在：尝试关闭结果弹窗
                    if (((Get-Date) - $script:LastQuizAt).TotalSeconds -gt 4) {
                        Dismiss-Quiz -QuizElement $quiz | Out-Null
                    }
                }

                Start-Sleep -Milliseconds 900
                continue
            }
            else {
                $script:WaitingManualQuizKey = $null
                if ($script:LastQuizKey) {
                    $script:LastQuizKey = $null
                    $script:LastQuizAt = [datetime]::MinValue
                }
            }

            $video = Get-VideoState -Document $ctx.Document
            if (-not $video.Element) {
                $script:NoVideoCount++
                if ($script:CurrentLabel -eq '测试') {
                    Write-Log '当前停在章节测试页，程序不会进入测试；请手动点左侧下一节，程序会继续。' Warn
                    Start-Sleep -Seconds 5
                    continue
                }

                # 有些小节只是目录页，没有视频；连续等不到视频时继续向后找
                if ($script:NoVideoCount -ge 5 -and $script:AdvanceFailures -lt 3) {
                    $script:AdvanceFailures++
                    Write-Log "页面连续 $($script:NoVideoCount) 次没有视频，尝试跳到下一节（第 $($script:AdvanceFailures)/3 次）..." Warn
                    $result = Move-NextSection -Context $ctx -Config $config
                    if ($result.Ok) {
                        $script:NoVideoCount = 0
                        $script:AdvanceFailures = 0
                        $script:LastEndedVideoId = $null
                        $lastState = ''
                        Start-Sleep -Seconds 2
                        continue
                    }
                    if ($result.Fatal) { break }
                    $script:NoVideoCount = 0
                    Write-Log '没有找到可播放的下一节，10 秒后重试...' Warn
                    Start-Sleep -Seconds 10
                    continue
                }

                Write-Log '当前页面没有视频元素，等待...' Warn
                Start-Sleep -Seconds 3
                continue
            }
            $script:NoVideoCount = 0

            if ($lastState -ne $video.State) {
                Write-Log "视频状态：$($video.State)"
                $lastState = $video.State
            }

            if ($video.State -eq 'ended') {
                if (-not $config.autoNext) {
                    Write-Log '视频已结束；autoNext=false，程序停止。' Ok
                    break
                }

                $videoId = Get-VideoRuntimeId -Video $video
                if ($script:LastEndedVideoId -ne $videoId) {
                    $script:LastEndedVideoId = $videoId
                    $script:EndedAt = Get-Date
                    $script:AdvanceFailures = 0
                    Write-Log '视频播放结束，先等待页面自动进入下一节...' Ok
                    Start-Sleep -Seconds 3
                    continue
                }

                $endedFor = ((Get-Date) - $script:EndedAt).TotalSeconds
                if ($endedFor -lt 7) {
                    Start-Sleep -Seconds 2
                    continue
                }

                if ($script:AdvanceFailures -ge 3) {
                    Write-Log '视频已结束，但连续 3 次都没有进入下一节；程序停止，请手动点下一节。' Error
                    break
                }

                $script:AdvanceFailures++
                Write-Log ("视频结束 {0:N0} 秒仍未进入下一节，第 {1}/3 次尝试跳过测试并查找下一节..." -f $endedFor, $script:AdvanceFailures) Warn
                $result = Move-NextSection -Context $ctx -Config $config
                if ($result.Ok) {
                    $script:LastEndedVideoId = $null
                    $script:EndedAt = [datetime]::MinValue
                    $script:AdvanceFailures = 0
                    $script:NoVideoCount = 0
                    $lastState = ''
                    Start-Sleep -Seconds 2
                    continue
                }
                if ($result.Fatal) { break }

                Write-Log '本次没有加载出下一节，15 秒后重试...' Warn
                Start-Sleep -Seconds 15
                continue
            }
            elseif ($video.State -eq 'paused') {
                $script:AdvanceFailures = 0
                if (((Get-Date) - $script:LastAdvanceAt).TotalSeconds -lt 8) {
                    Start-Sleep -Seconds 1
                    continue
                }
                Invoke-PlayVideo -Context $ctx
            }
            elseif ($video.State -eq 'playing') {
                $script:AdvanceFailures = 0
            }

            $cur = Find-CurrentSection -Document $ctx.Document
            if ($cur -and $cur -ne $script:CurrentLabel) {
                $script:CurrentLabel = $cur
                Write-Log "当前小节：$cur"
            }

            $emptyCycles = 0
            if ($Once) { break }
            Start-Sleep -Seconds ([int]$config.pollSeconds)
        }
        catch {
            $emptyCycles++
            Write-Log "循环出错：$($_.Exception.Message)" Error
            Start-Sleep -Seconds 3
            if ($Once -or $emptyCycles -ge 5) { break }
        }
    }

    Write-Log '程序已停止。' Ok
}

Main
