@echo off
chcp 65001 >nul
title Zhihuishu Helper
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ZhihuishuHelper.ps1"
echo.
pause
